﻿namespace Cinnova.Forms
{
    partial class FarmerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabPage2 = new TabPage();
            label12 = new Label();
            label11 = new Label();
            pnlTotalPurchases = new Panel();
            lblTotalPurchases = new Label();
            label6 = new Label();
            dgvPurchases = new DataGridView();
            lblRecentPurchases = new Label();
            pnlPurchaseCard = new Panel();
            btnSavePurchase = new Button();
            btnCalculate = new Button();
            dateTimePicker2 = new DateTimePicker();
            txtCost = new TextBox();
            txtPriceKg = new TextBox();
            txtQuantityKg = new TextBox();
            combofarmer = new ComboBox();
            cmbFarmer = new Label();
            dtpPurchaseDate = new Label();
            txtTotal = new Label();
            txtPrice = new Label();
            txtQuantity = new Label();
            label1 = new Label();
            panel1 = new Panel();
            btnDelete = new Button();
            btnAdd = new Button();
            dateTimePicker1 = new DateTimePicker();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            dtpDateAdded = new Label();
            textBox1 = new TextBox();
            txtLocation = new Label();
            txtContact = new Label();
            txtFullName = new Label();
            dgvFarmers = new DataGridView();
            label4 = new Label();
            tabPage1 = new TabPage();
            label10 = new Label();
            label9 = new Label();
            pnlBanner = new Panel();
            label8 = new Label();
            label7 = new Label();
            pnlTotalFarmers = new Panel();
            lblTotalNumber = new Label();
            label5 = new Label();
            pnlSidebar = new Panel();
            btnLogoutFarmer = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label3 = new Label();
            label2 = new Label();
            tabControl1 = new TabControl();
            tabPage2.SuspendLayout();
            pnlTotalPurchases.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvPurchases).BeginInit();
            pnlPurchaseCard.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvFarmers).BeginInit();
            tabPage1.SuspendLayout();
            pnlBanner.SuspendLayout();
            pnlTotalFarmers.SuspendLayout();
            pnlSidebar.SuspendLayout();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label12);
            tabPage2.Controls.Add(label11);
            tabPage2.Controls.Add(pnlTotalPurchases);
            tabPage2.Controls.Add(dgvPurchases);
            tabPage2.Controls.Add(lblRecentPurchases);
            tabPage2.Controls.Add(pnlPurchaseCard);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(992, 672);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Purchases";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = Color.Gray;
            label12.Location = new Point(315, 115);
            label12.Name = "label12";
            label12.Size = new Size(269, 15);
            label12.TabIndex = 18;
            label12.Text = "Record and view cinnamon purchase transactions";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 18F);
            label11.ForeColor = Color.FromArgb(78, 36, 16);
            label11.Location = new Point(315, 80);
            label11.Name = "label11";
            label11.Size = new Size(259, 32);
            label11.TabIndex = 17;
            label11.Text = "Purchase Management";
            // 
            // pnlTotalPurchases
            // 
            pnlTotalPurchases.BackColor = Color.FromArgb(76, 38, 16);
            pnlTotalPurchases.Controls.Add(lblTotalPurchases);
            pnlTotalPurchases.Controls.Add(label6);
            pnlTotalPurchases.Location = new Point(760, 70);
            pnlTotalPurchases.Name = "pnlTotalPurchases";
            pnlTotalPurchases.Size = new Size(180, 100);
            pnlTotalPurchases.TabIndex = 16;
            // 
            // lblTotalPurchases
            // 
            lblTotalPurchases.AutoSize = true;
            lblTotalPurchases.Font = new Font("Segoe UI", 22F);
            lblTotalPurchases.ForeColor = Color.White;
            lblTotalPurchases.Location = new Point(20, 15);
            lblTotalPurchases.Name = "lblTotalPurchases";
            lblTotalPurchases.Size = new Size(34, 41);
            lblTotalPurchases.TabIndex = 17;
            lblTotalPurchases.Text = "0";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.White;
            label6.Location = new Point(20, 65);
            label6.Name = "label6";
            label6.Size = new Size(107, 15);
            label6.TabIndex = 17;
            label6.Text = "TOTAL PURCHASES";
            // 
            // dgvPurchases
            // 
            dgvPurchases.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPurchases.BackgroundColor = Color.White;
            dgvPurchases.BorderStyle = BorderStyle.None;
            dgvPurchases.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPurchases.Location = new Point(685, 295);
            dgvPurchases.Name = "dgvPurchases";
            dgvPurchases.ReadOnly = true;
            dgvPurchases.RowHeadersVisible = false;
            dgvPurchases.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvPurchases.Size = new Size(590, 300);
            dgvPurchases.TabIndex = 13;
            // 
            // lblRecentPurchases
            // 
            lblRecentPurchases.AutoSize = true;
            lblRecentPurchases.Font = new Font("Segoe UI", 12F);
            lblRecentPurchases.ForeColor = Color.FromArgb(76, 38, 16);
            lblRecentPurchases.Location = new Point(389, 190);
            lblRecentPurchases.Name = "lblRecentPurchases";
            lblRecentPurchases.Size = new Size(131, 21);
            lblRecentPurchases.TabIndex = 15;
            lblRecentPurchases.Text = "Recent Purchases";
            // 
            // pnlPurchaseCard
            // 
            pnlPurchaseCard.BackColor = Color.White;
            pnlPurchaseCard.BorderStyle = BorderStyle.FixedSingle;
            pnlPurchaseCard.Controls.Add(btnSavePurchase);
            pnlPurchaseCard.Controls.Add(btnCalculate);
            pnlPurchaseCard.Controls.Add(dateTimePicker2);
            pnlPurchaseCard.Controls.Add(txtCost);
            pnlPurchaseCard.Controls.Add(txtPriceKg);
            pnlPurchaseCard.Controls.Add(txtQuantityKg);
            pnlPurchaseCard.Controls.Add(combofarmer);
            pnlPurchaseCard.Controls.Add(cmbFarmer);
            pnlPurchaseCard.Controls.Add(dtpPurchaseDate);
            pnlPurchaseCard.Controls.Add(txtTotal);
            pnlPurchaseCard.Controls.Add(txtPrice);
            pnlPurchaseCard.Controls.Add(txtQuantity);
            pnlPurchaseCard.Controls.Add(label1);
            pnlPurchaseCard.Location = new Point(30, 80);
            pnlPurchaseCard.Name = "pnlPurchaseCard";
            pnlPurchaseCard.Size = new Size(300, 420);
            pnlPurchaseCard.TabIndex = 14;
            // 
            // btnSavePurchase
            // 
            btnSavePurchase.Location = new Point(150, 365);
            btnSavePurchase.Name = "btnSavePurchase";
            btnSavePurchase.Size = new Size(95, 23);
            btnSavePurchase.TabIndex = 25;
            btnSavePurchase.Text = "Save Purchase";
            btnSavePurchase.UseVisualStyleBackColor = true;
            btnSavePurchase.Click += btnSavePurchase_Click;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(25, 365);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(75, 23);
            btnCalculate.TabIndex = 24;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(25, 315);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(200, 23);
            dateTimePicker2.TabIndex = 23;
            // 
            // txtCost
            // 
            txtCost.Location = new Point(25, 250);
            txtCost.Name = "txtCost";
            txtCost.Size = new Size(100, 23);
            txtCost.TabIndex = 22;
            // 
            // txtPriceKg
            // 
            txtPriceKg.Location = new Point(25, 185);
            txtPriceKg.Name = "txtPriceKg";
            txtPriceKg.Size = new Size(100, 23);
            txtPriceKg.TabIndex = 21;
            // 
            // txtQuantityKg
            // 
            txtQuantityKg.Location = new Point(25, 120);
            txtQuantityKg.Name = "txtQuantityKg";
            txtQuantityKg.Size = new Size(100, 23);
            txtQuantityKg.TabIndex = 20;
            // 
            // combofarmer
            // 
            combofarmer.FormattingEnabled = true;
            combofarmer.Location = new Point(25, 55);
            combofarmer.Name = "combofarmer";
            combofarmer.Size = new Size(121, 23);
            combofarmer.TabIndex = 19;
            // 
            // cmbFarmer
            // 
            cmbFarmer.AutoSize = true;
            cmbFarmer.Location = new Point(25, 30);
            cmbFarmer.Name = "cmbFarmer";
            cmbFarmer.Size = new Size(78, 15);
            cmbFarmer.TabIndex = 18;
            cmbFarmer.Text = "Select Farmer";
            // 
            // dtpPurchaseDate
            // 
            dtpPurchaseDate.AutoSize = true;
            dtpPurchaseDate.Location = new Point(25, 290);
            dtpPurchaseDate.Name = "dtpPurchaseDate";
            dtpPurchaseDate.Size = new Size(82, 15);
            dtpPurchaseDate.TabIndex = 17;
            dtpPurchaseDate.Text = "Purchase Date";
            // 
            // txtTotal
            // 
            txtTotal.AutoSize = true;
            txtTotal.Location = new Point(25, 225);
            txtTotal.Name = "txtTotal";
            txtTotal.Size = new Size(59, 15);
            txtTotal.TabIndex = 16;
            txtTotal.Text = "Total Cost";
            // 
            // txtPrice
            // 
            txtPrice.AutoSize = true;
            txtPrice.Location = new Point(25, 160);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(70, 15);
            txtPrice.TabIndex = 15;
            txtPrice.Text = "Price Per Kg";
            // 
            // txtQuantity
            // 
            txtQuantity.AutoSize = true;
            txtQuantity.Location = new Point(25, 95);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(75, 15);
            txtQuantity.TabIndex = 14;
            txtQuantity.Text = "Quantity(Kg)";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-6, 93);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 13;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(btnDelete);
            panel1.Controls.Add(btnAdd);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(dtpDateAdded);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(txtLocation);
            panel1.Controls.Add(txtContact);
            panel1.Controls.Add(txtFullName);
            panel1.Location = new Point(30, 180);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 420);
            panel1.TabIndex = 24;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(78, 36, 16);
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(140, 310);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(100, 35);
            btnDelete.TabIndex = 22;
            btnDelete.Text = "Delete Farmer";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(78, 36, 16);
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(20, 310);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(100, 35);
            btnAdd.TabIndex = 21;
            btnAdd.Text = "Add Farmer";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Segoe UI", 9F);
            dateTimePicker1.Location = new Point(20, 250);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(230, 23);
            dateTimePicker1.TabIndex = 19;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 9F);
            textBox3.Location = new Point(20, 185);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(230, 23);
            textBox3.TabIndex = 18;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 9F);
            textBox2.Location = new Point(20, 120);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(230, 23);
            textBox2.TabIndex = 17;
            // 
            // dtpDateAdded
            // 
            dtpDateAdded.AutoSize = true;
            dtpDateAdded.Font = new Font("Segoe UI", 9F);
            dtpDateAdded.Location = new Point(20, 225);
            dtpDateAdded.Name = "dtpDateAdded";
            dtpDateAdded.Size = new Size(89, 15);
            dtpDateAdded.TabIndex = 20;
            dtpDateAdded.Text = "Registered Date";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 9F);
            textBox1.Location = new Point(20, 55);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(230, 23);
            textBox1.TabIndex = 16;
            // 
            // txtLocation
            // 
            txtLocation.AutoSize = true;
            txtLocation.Font = new Font("Segoe UI", 9F);
            txtLocation.Location = new Point(20, 160);
            txtLocation.Name = "txtLocation";
            txtLocation.Size = new Size(53, 15);
            txtLocation.TabIndex = 15;
            txtLocation.Text = "Location";
            // 
            // txtContact
            // 
            txtContact.AutoSize = true;
            txtContact.Font = new Font("Segoe UI", 9F);
            txtContact.Location = new Point(20, 95);
            txtContact.Name = "txtContact";
            txtContact.Size = new Size(102, 15);
            txtContact.TabIndex = 14;
            txtContact.Text = "Contact  Number ";
            // 
            // txtFullName
            // 
            txtFullName.AutoSize = true;
            txtFullName.Font = new Font("Segoe UI", 9F);
            txtFullName.Location = new Point(20, 30);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(79, 15);
            txtFullName.TabIndex = 13;
            txtFullName.Text = "Farmer Name";
            txtFullName.Click += txtFullName_Click;
            // 
            // dgvFarmers
            // 
            dgvFarmers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvFarmers.BackgroundColor = Color.White;
            dgvFarmers.BorderStyle = BorderStyle.None;
            dgvFarmers.ColumnHeadersHeight = 35;
            dgvFarmers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvFarmers.Location = new Point(655, 290);
            dgvFarmers.MultiSelect = false;
            dgvFarmers.Name = "dgvFarmers";
            dgvFarmers.ReadOnly = true;
            dgvFarmers.RowHeadersVisible = false;
            dgvFarmers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvFarmers.Size = new Size(600, 300);
            dgvFarmers.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F);
            label4.ForeColor = Color.FromArgb(78, 36, 16);
            label4.Location = new Point(3, 1);
            label4.Name = "label4";
            label4.Size = new Size(237, 32);
            label4.TabIndex = 0;
            label4.Text = "Farmer Management";
            label4.Click += label4_Click_2;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(255, 247, 237);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(pnlBanner);
            tabPage1.Controls.Add(pnlTotalFarmers);
            tabPage1.Controls.Add(dgvFarmers);
            tabPage1.Controls.Add(panel1);
            tabPage1.Controls.Add(label4);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(992, 672);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Farmer Management";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.Gray;
            label10.Location = new Point(660, 255);
            label10.Name = "label10";
            label10.Size = new Size(208, 15);
            label10.TabIndex = 28;
            label10.Text = "Showing registered cinnamon farmers";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F);
            label9.ForeColor = Color.FromArgb(76, 38, 16);
            label9.Location = new Point(660, 230);
            label9.Name = "label9";
            label9.Size = new Size(127, 21);
            label9.TabIndex = 27;
            label9.Text = "Farmer Directory";
            // 
            // pnlBanner
            // 
            pnlBanner.BackColor = Color.White;
            pnlBanner.Controls.Add(label8);
            pnlBanner.Controls.Add(label7);
            pnlBanner.Location = new Point(350, 50);
            pnlBanner.Name = "pnlBanner";
            pnlBanner.Size = new Size(350, 110);
            pnlBanner.TabIndex = 26;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.Gray;
            label8.Location = new Point(20, 60);
            label8.Name = "label8";
            label8.Size = new Size(257, 15);
            label8.TabIndex = 30;
            label8.Text = "Manage and nurture relationships with farmers.";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 16F);
            label7.ForeColor = Color.FromArgb(76, 38, 16);
            label7.Location = new Point(20, 20);
            label7.Name = "label7";
            label7.Size = new Size(285, 30);
            label7.TabIndex = 29;
            label7.Text = "Sustainable Farmer Network";
            // 
            // pnlTotalFarmers
            // 
            pnlTotalFarmers.BackColor = Color.FromArgb(76, 38, 16);
            pnlTotalFarmers.Controls.Add(lblTotalNumber);
            pnlTotalFarmers.Controls.Add(label5);
            pnlTotalFarmers.Location = new Point(760, 55);
            pnlTotalFarmers.Name = "pnlTotalFarmers";
            pnlTotalFarmers.Size = new Size(200, 100);
            pnlTotalFarmers.TabIndex = 25;
            // 
            // lblTotalNumber
            // 
            lblTotalNumber.AutoSize = true;
            lblTotalNumber.Font = new Font("Segoe UI", 24F);
            lblTotalNumber.ForeColor = Color.White;
            lblTotalNumber.Location = new Point(20, 15);
            lblTotalNumber.Name = "lblTotalNumber";
            lblTotalNumber.Size = new Size(37, 45);
            lblTotalNumber.TabIndex = 28;
            lblTotalNumber.Text = "1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 8F);
            label5.ForeColor = Color.White;
            label5.Location = new Point(20, 65);
            label5.Name = "label5";
            label5.Size = new Size(128, 13);
            label5.TabIndex = 27;
            label5.Text = "TOTAL ACTIVE FARMERS";
            // 
            // pnlSidebar
            // 
            pnlSidebar.BackColor = Color.FromArgb(76, 38, 16);
            pnlSidebar.Controls.Add(btnLogoutFarmer);
            pnlSidebar.Controls.Add(button9);
            pnlSidebar.Controls.Add(button8);
            pnlSidebar.Controls.Add(button7);
            pnlSidebar.Controls.Add(button6);
            pnlSidebar.Controls.Add(button5);
            pnlSidebar.Controls.Add(button4);
            pnlSidebar.Controls.Add(button3);
            pnlSidebar.Controls.Add(button2);
            pnlSidebar.Controls.Add(button1);
            pnlSidebar.Controls.Add(label3);
            pnlSidebar.Controls.Add(label2);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Location = new Point(0, 0);
            pnlSidebar.Name = "pnlSidebar";
            pnlSidebar.Size = new Size(180, 541);
            pnlSidebar.TabIndex = 11;
            pnlSidebar.Paint += pnlSidebar_Paint;
            // 
            // btnLogoutFarmer
            // 
            btnLogoutFarmer.Location = new Point(20, 560);
            btnLogoutFarmer.Name = "btnLogoutFarmer";
            btnLogoutFarmer.Size = new Size(75, 23);
            btnLogoutFarmer.TabIndex = 22;
            btnLogoutFarmer.Text = "Logout";
            btnLogoutFarmer.UseVisualStyleBackColor = true;
            btnLogoutFarmer.Click += btnLogoutFarmer_Click;
            // 
            // button9
            // 
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = FlatStyle.Flat;
            button9.ForeColor = Color.White;
            button9.Location = new Point(20, 410);
            button9.Name = "button9";
            button9.Size = new Size(151, 23);
            button9.TabIndex = 21;
            button9.Text = "User Management";
            button9.TextAlign = ContentAlignment.MiddleLeft;
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button8
            // 
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatStyle = FlatStyle.Flat;
            button8.ForeColor = Color.White;
            button8.Location = new Point(20, 370);
            button8.Name = "button8";
            button8.Size = new Size(151, 23);
            button8.TabIndex = 20;
            button8.Text = "Reports and  Analytics";
            button8.TextAlign = ContentAlignment.MiddleLeft;
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button7
            // 
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.ForeColor = Color.White;
            button7.Location = new Point(20, 330);
            button7.Name = "button7";
            button7.Size = new Size(151, 23);
            button7.TabIndex = 19;
            button7.Text = "Employee Management\n";
            button7.TextAlign = ContentAlignment.MiddleLeft;
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button6
            // 
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.ForeColor = Color.White;
            button6.Location = new Point(20, 250);
            button6.Name = "button6";
            button6.Size = new Size(151, 23);
            button6.TabIndex = 18;
            button6.Text = "Export Management\n";
            button6.TextAlign = ContentAlignment.MiddleLeft;
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.ForeColor = Color.White;
            button5.Location = new Point(20, 130);
            button5.Name = "button5";
            button5.Size = new Size(151, 23);
            button5.TabIndex = 17;
            button5.Text = "Farmer Management";
            button5.TextAlign = ContentAlignment.MiddleLeft;
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.ForeColor = Color.White;
            button4.Location = new Point(20, 290);
            button4.Name = "button4";
            button4.Size = new Size(151, 23);
            button4.TabIndex = 16;
            button4.Text = "Sales and Billing";
            button4.TextAlign = ContentAlignment.MiddleLeft;
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.White;
            button3.Location = new Point(20, 210);
            button3.Name = "button3";
            button3.Size = new Size(151, 23);
            button3.TabIndex = 15;
            button3.Text = "Inventory Management\n";
            button3.TextAlign = ContentAlignment.MiddleLeft;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.White;
            button2.Location = new Point(20, 170);
            button2.Name = "button2";
            button2.Size = new Size(151, 23);
            button2.TabIndex = 14;
            button2.Text = "Production Management";
            button2.TextAlign = ContentAlignment.MiddleLeft;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.White;
            button1.Location = new Point(20, 91);
            button1.Name = "button1";
            button1.Size = new Size(151, 23);
            button1.TabIndex = 13;
            button1.Text = "Dashboard";
            button1.TextAlign = ContentAlignment.MiddleLeft;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.White;
            label3.Location = new Point(29, 39);
            label3.Name = "label3";
            label3.Size = new Size(117, 15);
            label3.TabIndex = 12;
            label3.Text = "CINNAMON EXPORT";
            label3.Click += label3_Click_2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(29, 14);
            label2.Name = "label2";
            label2.Size = new Size(81, 25);
            label2.TabIndex = 12;
            label2.Text = "Cinnova";
            label2.Click += label2_Click_3;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(200, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1000, 700);
            tabControl1.TabIndex = 0;
            // 
            // FarmerForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(245, 241, 236);
            ClientSize = new Size(884, 541);
            Controls.Add(pnlSidebar);
            Controls.Add(tabControl1);
            Name = "FarmerForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Farmer Management";
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            pnlTotalPurchases.ResumeLayout(false);
            pnlTotalPurchases.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvPurchases).EndInit();
            pnlPurchaseCard.ResumeLayout(false);
            pnlPurchaseCard.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvFarmers).EndInit();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            pnlBanner.ResumeLayout(false);
            pnlBanner.PerformLayout();
            pnlTotalFarmers.ResumeLayout(false);
            pnlTotalFarmers.PerformLayout();
            pnlSidebar.ResumeLayout(false);
            pnlSidebar.PerformLayout();
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabPage tabPage2;
        private DataGridView dgvPurchases;
        private TabPage tabPage1;
        private Panel pnlSidebar;
        private Button btnLogoutFarmer;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label3;
        private Label label2;
        private TabControl tabControl1;
        private Label label4;
        private Panel panel1;
        private DataGridView dgvFarmers;
        private Button btnDelete;
        private Button btnAdd;
        private Label dtpDateAdded;
        private DateTimePicker dateTimePicker1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label txtLocation;
        private Label txtContact;
        private Label txtFullName;
        private Panel pnlBanner;
        private Panel pnlTotalFarmers;
        private Label label5;
        private Label lblTotalNumber;
        private Label label7;
        private Label label8;
        private Panel pnlPurchaseCard;
        private Button btnSavePurchase;
        private Button btnCalculate;
        private DateTimePicker dateTimePicker2;
        private TextBox txtCost;
        private TextBox txtPriceKg;
        private TextBox txtQuantityKg;
        private ComboBox combofarmer;
        private Label cmbFarmer;
        private Label dtpPurchaseDate;
        private Label txtTotal;
        private Label txtPrice;
        private Label txtQuantity;
        private Label label1;
        private Label lblRecentPurchases;
        private Label label6;
        private Panel pnlTotalPurchases;
        private Label lblTotalPurchases;
        private Label label10;
        private Label label9;
        private Label label11;
        private Label label12;
    }
}